This directory contains a set of images (*.bmp) and audio file to be used
with the NUCLEO-F303RE demonstrations.
